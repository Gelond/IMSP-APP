package uac.imsp.clockingapp.View.util;

public interface IGeneralMenuView {


    void onSearchEmployeeMenuSuccessfull();
    void onUpdateEmployeeMenuSuccessfull();
    void onDeleteEmployeeMenuSucessfull();
    void onRegisterEmployeeMenuSuccessful();
    void onConsultatisticsMenuSuccessful();
    void onClocking();
    void onConsultPresenceReport();
    void onExit();



}
