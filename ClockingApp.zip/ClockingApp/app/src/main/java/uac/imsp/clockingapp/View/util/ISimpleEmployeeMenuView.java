package uac.imsp.clockingapp.View.util;

public interface ISimpleEmployeeMenuView {

	void onConsultatisticsMenuSuccessful();
	void onClocking();
	void onSettings();
	void onConsultPresenceReport();
	void onExit();

}
