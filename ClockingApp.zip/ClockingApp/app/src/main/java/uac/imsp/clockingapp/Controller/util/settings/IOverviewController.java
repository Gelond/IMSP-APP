package uac.imsp.clockingapp.Controller.util.settings;

public interface IOverviewController {
	//void onCopy(String text);
}
