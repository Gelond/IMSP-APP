package uac.imsp.clockingapp.View.util.settings.others;

public interface IDarkModeView {
	void onDarkMode();
}
