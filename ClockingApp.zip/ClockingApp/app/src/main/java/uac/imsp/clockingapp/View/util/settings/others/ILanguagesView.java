package uac.imsp.clockingapp.View.util.settings.others;

public interface ILanguagesView {
	  void  onLanguageChanged(String lang);
}
