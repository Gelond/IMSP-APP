package uac.imsp.clockingapp.Controller.util;

public interface IPersonalInformationsController {

	void onUpdate(String email);

	void onStart(int number);
}
