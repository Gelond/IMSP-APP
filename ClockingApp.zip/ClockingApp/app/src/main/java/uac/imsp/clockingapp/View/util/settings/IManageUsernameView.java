package uac.imsp.clockingapp.View.util.settings;

public interface IManageUsernameView {
}
