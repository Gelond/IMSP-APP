package uac.imsp.clockingapp.Controller.util;

public interface IMenuController {
    void onParametersMenu();
    void onDarkMode();
    void onLanguageMenu();
    void onFreeMemory();
    void onReportProblem();
    void onLeave();
    void onLanguageSelected(int which);

}
