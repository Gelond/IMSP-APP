package entity;
/** Provides interface for Planning
 *@see  Planning**/
public interface IPlanning {
     int getId();
     String getStartTime();
     String getEndTime();
}
