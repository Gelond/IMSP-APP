package uac.imsp.clockingapp.Controller.util.settings.others;

public interface IDarkModeController {
	void onDarkMode();
}
