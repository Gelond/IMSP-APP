package uac.imsp.clockingapp.Controller.control.settings;

public class SimpeEmployeeSettingsController {
}
