package uac.imsp.clockingapp.Controller.util;

public interface IGeneralMenuController {


    void onSearchEmployeeMenu(int currentUser);
    boolean onRegisterEmployeeMenu(int currentUser);
    void onClocking();
    void onConsultatisticsMenu(int currentUser);
    void onExit();

}

