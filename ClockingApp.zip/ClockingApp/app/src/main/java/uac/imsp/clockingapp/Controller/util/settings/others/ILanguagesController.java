package uac.imsp.clockingapp.Controller.util.settings.others;

public interface ILanguagesController {
	void onLanguageChanged(String lang);
}
