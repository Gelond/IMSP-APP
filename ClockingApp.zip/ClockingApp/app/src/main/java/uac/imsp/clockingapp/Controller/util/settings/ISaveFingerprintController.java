package uac.imsp.clockingapp.Controller.util.settings;

public interface ISaveFingerprintController {
}
