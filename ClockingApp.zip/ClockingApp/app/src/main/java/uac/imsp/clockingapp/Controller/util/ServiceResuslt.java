package uac.imsp.clockingapp.Controller.util;

import entity.Service;

public class ServiceResuslt extends Service {
	public ServiceResuslt(int id){
		super(id);

	}

}
