package uac.imsp.clockingapp.Controller.util;

public interface ISimpleEmployeeMenuController {
	void onClocking();
	void onConsultatisticsMenu();
	void onConsultPresentReport();
	void onExit();

	void onSettings();
}
