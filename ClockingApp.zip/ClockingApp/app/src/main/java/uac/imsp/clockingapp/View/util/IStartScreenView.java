package uac.imsp.clockingapp.View.util;
public interface IStartScreenView {
    void onLogin();
    void onClocking();
    

    void onFirstRun();

    void onUpgrade();

    void onNormalRun();

	void onSetUp();

    void onService();

    void onAccount();

    void onDowngrade();
}
