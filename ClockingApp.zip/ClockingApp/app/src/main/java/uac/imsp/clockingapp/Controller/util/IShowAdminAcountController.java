package uac.imsp.clockingapp.Controller.util;

public interface IShowAdminAcountController {
	void onLoad();
	void onCopyAccount();
	void onNext();
}
