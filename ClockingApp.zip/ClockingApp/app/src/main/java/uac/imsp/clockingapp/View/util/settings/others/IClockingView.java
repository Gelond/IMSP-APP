package uac.imsp.clockingapp.View.util.settings.others;

public interface IClockingView {
	void onUseQRCode();
	void onUseFingerPrint();
}
