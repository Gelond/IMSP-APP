package uac.imsp.clockingapp.View.util;

public interface IDeleteEmployeeView {

    void onDeleteSuccessfull();
    void askConfirmDelete();


	void onError(int errorNumber);
}


