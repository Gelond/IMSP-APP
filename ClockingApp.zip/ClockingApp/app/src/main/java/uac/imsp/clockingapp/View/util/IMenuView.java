package uac.imsp.clockingapp.View.util;

public interface IMenuView {

    void onLanguageMenu();
    void changeLanguageTo(String lang);

}
