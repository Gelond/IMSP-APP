package uac.imsp.clockingapp.View.util;

public interface IShowAdminAcountView {
	void onStart(String username,String password);
	void onCopyAccount();
	void onNext();
}
