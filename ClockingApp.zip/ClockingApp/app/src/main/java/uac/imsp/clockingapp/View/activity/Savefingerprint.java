package uac.imsp.clockingapp.View.activity;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;

import com.google.firebase.auth.FirebaseAuth;

import uac.imsp.clockingapp.R;

public class Savefingerprint extends AppCompatActivity  {
	private FirebaseAuth firebaseAuth;
	private BiometricPrompt biometricPrompt;
	private BiometricPrompt.PromptInfo promptInfo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_savefingerprint);
		// calling the action bar
		ActionBar actionBar = getSupportActionBar();
// showing the back button in action bar
		assert actionBar != null;
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setTitle(R.string.save_fingerprint);

		//Write a message to the database
		///FirebaseDatabase database = FirebaseDatabase.getInstance();
		//DatabaseReference myRef = database.getReference("message");

		//myRef.setValue("Hello, World!");

		firebaseAuth = FirebaseAuth.getInstance();
		BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this);
		biometricPrompt = builder.build();

	}
}