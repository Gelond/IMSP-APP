package uac.imsp.clockingapp.Controller.control.settings;

import uac.imsp.clockingapp.Controller.util.settings.IOverviewController;

public class OverviewController implements IOverviewController {

}
