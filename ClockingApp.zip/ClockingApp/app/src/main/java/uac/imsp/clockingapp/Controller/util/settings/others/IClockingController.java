package uac.imsp.clockingapp.Controller.util.settings.others;

public interface IClockingController {
	void onUseQRCode();
	void onUseFingerPrint();
}
