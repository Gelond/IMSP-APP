package entity;
/** Provides interface for Service
 *@see  Service**/
public interface IService {
    int getId();
    String getName();
}
