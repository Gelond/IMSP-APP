package uac.imsp.clockingapp.Controller.util;

public interface IStartScreenController {
    void onLogin();
    void onClocking();

    void onLoad(int savedVersionCode, int currentVersionCode);
}
