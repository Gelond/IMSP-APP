package uac.imsp.clockingapp.View.util.settings;

public interface ISimpleEmployeeSettingsView {
	void onAccount();

	void onPersonalInfos();

	void onUserDocs();

	void onDarkMode();

	void onLanguage();

	void onProblem();

	void onHelp();

	void onSaveFingerprint();
}
