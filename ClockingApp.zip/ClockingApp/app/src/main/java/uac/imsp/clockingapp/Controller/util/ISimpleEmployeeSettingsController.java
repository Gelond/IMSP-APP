package uac.imsp.clockingapp.Controller.util;

public interface ISimpleEmployeeSettingsController {
	void onMyAccount();

	void onPersonalInfos();

	void onUserDocs();

	void onDarkMode();

	void onLanguage();

	void onProblem();

	void onHelp();

	void onSaveFingerprint();
}
