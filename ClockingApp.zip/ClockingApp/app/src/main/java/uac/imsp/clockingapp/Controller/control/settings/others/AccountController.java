package uac.imsp.clockingapp.Controller.control.settings.others;

import uac.imsp.clockingapp.Controller.util.settings.IAccountController;

public class AccountController  implements IAccountController {
}
