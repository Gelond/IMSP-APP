package entity;

/** Provides interface for Day
*@see  Day**/
public interface IDay {
    int getId();
    String getDate();
}
