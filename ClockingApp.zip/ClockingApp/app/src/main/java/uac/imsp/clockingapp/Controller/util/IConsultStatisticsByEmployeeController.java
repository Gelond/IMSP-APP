package uac.imsp.clockingapp.Controller.util;

public interface IConsultStatisticsByEmployeeController {

    void onConsultStatisticsForEmployee(int number);
   // void onMonthSelected(int month) ;
    void onPreviousMonth();
    void onNextMonth();

}
